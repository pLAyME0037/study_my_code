import java.util.Locale;
import java.util.Scanner;
import java.util.Arrays;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.Console;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.DataOutputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.BufferedInputStream;

class iostream {
    static FileInputStream in = null;
    static FileOutputStream out = null;

    public static void main(String[] args) throws IOException {
        // byteStream();
        // charStream();
        // readCharStream();
        // scanRead();
        // usingConsole();
        // System.out.format("%f, %1$+020.10f %n", Math.PI);
        // writeDataStream();
        // readDataStream();
        writeObjStream();
        readObjStream();
    }

    public static void byteStream() throws IOException {
        try {
            in = new FileInputStream("./data_files/input_text.txt");
            out = new FileOutputStream("./data_files/output_text.txt");
            String message = "message: Hello, World.\n";
            out.write(message.getBytes());
            int c;
            while ((c = in.read()) != -1) { out.write(c); }
        } finally {
            if (in != null) in.close();
            if (out != null) out.close();
        }
    }

    public static void charStream() throws IOException {
        FileWriter fw = null;
        FileReader fr = null;

        try {
            fr = new FileReader("./data_files/input_text.txt");
            fw = new FileWriter("./data_files/output_text.txt");

            String message = "Message: Hello, World.\n";
            fw.write(message);
            int c;
            while ((c = fr.read()) != -1) { fw.write(c); }
        } finally {
            if (fr != null) fr.close();
            if (fw != null) fw.close();
        }
    }

    public static void readCharStream() throws IOException {
        BufferedReader is = null;
        PrintWriter    os = null;

        try {
            is = new BufferedReader(
                 new FileReader("./data_files/input_text.txt"));
            os = new PrintWriter(
                 new FileWriter("./data_files/output_text.txt"));

            String l;
            while ((l = is.readLine()) != null) {
                System.out.println(l);
                // os.write(l);
                os.println(l);
            }
        } finally {
            if (is != null) is.close();
            if (os != null) os.close();
        }
    }

    public static void scanRead() throws IOException {
        Scanner s = null;
        double number = 0;

        try {
            s = new Scanner(
                new BufferedReader(
                new FileReader("./data_files/input_text.txt")));
            // s.useDelimiter(",\\s*"); // comma & optional space
            while (s.hasNext()) { System.out.println(s.next()); }
        } finally {
            if (s != null) s.close();
        }

        System.out.println("----------------------------");

        try {
            s = new Scanner(
                new BufferedReader(
                new FileReader("./data_files/number.txt")));
            s.useLocale(Locale.US);
            while (s.hasNext()) {
                if (s.hasNextDouble()) { number += s.nextDouble(); }
                else { s.next(); }
            }
        } finally {
            if (s != null) s.close();
        }
        System.out.printf("Sum: %.2f%n", number);
    }

    public static void usingConsole() {
        Console c = System.console();
        if (c == null) {
            System.out.println("No console was found.");
            System.exit(1);
        }

        char[] password = c.readPassword("Enter Your Password: ");
        String oldPasswordT = "12345678";
        if (!verify(oldPasswordT, password)) {
            System.out.println("Wrong Password!");
            Arrays.fill(password, ' ');
            System.exit(1);
        }

        boolean isMatch = false;
        do {
            char[] newPW  = c.readPassword("Enter new Password: ");
            char[] newPWC = c.readPassword("Confirm new Password: ");

            if (Arrays.equals(newPW, newPWC)) {
                change(oldPasswordT, newPW);
                c.format("Password change successfully %n");
                c.format("Password %s has change. %n", password);

                Arrays.fill(newPW, ' ');
                Arrays.fill(newPWC, ' ');

                isMatch = true;
            } else {
                c.format("Password do not match. Try Agian!");
            }
        } while (!isMatch);
        Arrays.fill(password, ' ');
    }

    static boolean verify(String pass, char[] oldPass) {
        return Arrays.equals(pass.toCharArray(), oldPass);
    }

    static void change(String login, char[] password) {
        System.out.println("Updating password...");
    }

    static final String dataFile = "./data_files/invoicedata";
    static final double[] prices = { 19.99, 9.99, 15.99, 3.99, 4.99 };
    static final int[] units = { 12, 8, 13, 29, 50 };
    static final String[] descs = {
        "Java T-shirt",
        "Java Mug",
        "java Duke Juggling Dolls",
        "Java Pin",
        "Java Key Chain"
    };

    public static void writeDataStream() throws IOException {
        try (DataOutputStream out = new DataOutputStream(
                                    new BufferedOutputStream(
                                    new FileOutputStream(dataFile)))) {
            for (int i = 0; i < prices.length; ++i) {
                out.writeDouble(prices[i]);
                out.writeInt(units[i]);
                out.writeUTF(descs[i]);
            }
        }
    }

    public static void readDataStream() {
        double total = 0.0;

        try (DataInputStream in = new DataInputStream(
                                  new BufferedInputStream(
                                  new FileInputStream(dataFile)))) {
            double price;
            int unit;
            String desc;

            while (true) {
                price = in.readDouble();
                unit  = in.readInt();
                desc  = in.readUTF();
                System.out.format("You ordered %d units of %s at $%.2f%n",
                                  unit, desc, price);
                total += unit * price;
            }
        } catch (EOFException e) {
            System.out.printf("Total: $%.2f", total);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static class orderObject implements Serializable {
        double price;
        int unit;
        String desc;

        public orderObject(String desc, double price, int unit) {
            this.unit = unit;
            this.price = price;
            this.desc = desc;
        }
    }

    public static void writeObjStream() throws IOException {
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        try {
            fos = new FileOutputStream(dataFile);
            out = new ObjectOutputStream(
                  new BufferedOutputStream(fos));
            for(int i = 0; i < units.length; ++i) {
                orderObject item = new orderObject(descs[i], prices[i], units[i]);
                out.writeObject(item);
            }
        } finally {
            if (out != null) out.close();
            else if (fos != null) fos.close();
        } 
    }

    public static void readObjStream() { 
        double total = 0.0;

        try (ObjectInputStream in = new ObjectInputStream(
                                    new BufferedInputStream(
                                    new FileInputStream(dataFile)))) {
            while (true) {
                orderObject item = (orderObject) in.readObject();
                System.out.format("You ordered %d units of %s at $%.2f%n",
                                  item.unit, item.desc, item.price);
                total += item.unit * item.price;
            }
        } catch (EOFException e) {
            System.out.printf("Total: $%.2f", total);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}
